/* ============================================================================
   SAMARKAND RESTAURANT — конфигурация сайта
   ----------------------------------------------------------------------------
   ЭТО ЕДИНСТВЕННЫЙ ФАЙЛ, КОТОРЫЙ НУЖНО ПРАВИТЬ ДЛЯ СМЕНЫ КОНТАКТОВ,
   ЧАСОВ РАБОТЫ И ССЫЛОК. Код трогать не нужно.
   Формат — обычный объект (как JSON). Правь значения справа от двоеточия.
   ========================================================================== */

window.SAMARKAND_SITE = {

  /* --- Основное ---------------------------------------------------------- */
  name: "Samarkand Restaurant",
  legalName: "Sanat Shokirov",
  // Домен ещё не куплен. После покупки впиши сюда — подтянется в SEO и sitemap.
  canonical: "https://samarkanddenver.com",

  /* --- Контакты ---------------------------------------------------------- */
  phone: "+17206207819",          // формат для tel:
  phoneDisplay: "(720) 620-7819", // как показывать на сайте
  whatsapp: "17206207819",        // формат для wa.me — без + и пробелов
  email: "samarkand.den@gmail.com",

  /* --- Адрес ------------------------------------------------------------- */
  address: {
    street: "1842 S Parker Rd",
    city: "Denver",
    state: "CO",
    zip: "80231",
    country: "US",
    lat: 39.6834987,
    lng: -104.8808459
  },
  // Ссылка «Проложить маршрут»
  directionsUrl: "https://www.google.com/maps/dir/?api=1&destination=Samarkand+Restaurant,+1842+S+Parker+Rd,+Denver,+CO+80231",
  // Встроенная карта (iframe), работает без API-ключа.
  // Метку ставим по точным координатам ресторана, а не по адресу дома:
  // по адресу Google ставил булавку в центр парковки, мимо входа.
  mapEmbedUrl: "https://maps.google.com/maps?q=39.6834987,-104.8808459(Samarkand+Restaurant)&t=&z=18&ie=UTF8&iwloc=B&output=embed",

  /* --- Часы работы -------------------------------------------------------
     Понедельник — выходной. Вторник–воскресенье 12:00–22:00.
     open/close в 24-часовом формате "HH:MM". null = закрыто.
     Индикатор «Открыто сейчас» считается по времени Денвера автоматически. */
  timezone: "America/Denver",
  hours: [
    { day: 0, key: "sun", open: "12:00", close: "22:00" },
    { day: 1, key: "mon", open: null,    close: null    },
    { day: 2, key: "tue", open: "12:00", close: "22:00" },
    { day: 3, key: "wed", open: "12:00", close: "22:00" },
    { day: 4, key: "thu", open: "12:00", close: "22:00" },
    { day: 5, key: "fri", open: "12:00", close: "22:00" },
    { day: 6, key: "sat", open: "12:00", close: "22:00" }
  ],

  /* --- Зал --------------------------------------------------------------- */
  seats: 40,
  tableSizes: [2, 4, 6],   // варианты столов для формы бронирования
  priceRange: "$$",        // средний чек $30–45 на человека

  /* --- Сервисы доставки ---------------------------------------------------
     Grubhub и Seamless убраны — рабочих ссылок нет.
     Когда клиент подключит Grubhub, добавь сюда объект и он появится на сайте:
     { id:"grubhub", label:"Grubhub", url:"https://...", accent:"#F63440" }   */
  delivery: [
    {
      id: "doordash",
      label: "DoorDash",
      accent: "#EF2A32",
      url: "https://www.doordash.com/store/registan-kebab-house-denver-40743681/96871817/?pickup=true&utm_campaign=gpa"
    },
    {
      id: "ubereats",
      label: "Uber Eats",
      accent: "#06C167",
      url: "https://www.ubereats.com/store/registan-kebab-house/Ws9cPrsvRVKWD_NHyEs9XQ?diningMode=PICKUP"
    }
  ],

  /* --- Соцсети и отзывы -------------------------------------------------- */
  social: {
    instagram: "https://www.instagram.com/samarkand.den/",
    facebook: "",   // впиши, когда страница будет настроена
    yelp: "https://www.yelp.com/biz/registan-kebab-house-denver",
    google: "https://maps.app.goo.gl/CKz3HHcm7onSx2qS9"
  },

  /* --- Hero ---------------------------------------------------------------
     Видео решили не снимать. Если позже снимете — положите файл в
     assets/video/hero.mp4 и впишите путь в heroVideo. Сайт сам переключится
     на видео и оставит фото как poster. */
  heroImage: "assets/img/hero.jpg",
  heroVideo: null,

  /* --- Преимущества («Почему мы») ----------------------------------------
     Все пункты подтверждены владельцем: халяль, казан/тандыр, ручная лепка,
     большой зал, без алкоголя, бесплатная парковка, Wi-Fi, детское меню,
     оплата картой. enabled:false скрывает пункт, не удаляя его. */
  amenities: [
    { id: "halal",    icon: "halal",   enabled: true  },
    { id: "kazan",    icon: "flame",   enabled: true  },
    { id: "handmade", icon: "hands",   enabled: true  },
    { id: "family",   icon: "table",   enabled: true  },
    { id: "noalcohol",icon: "leaf",    enabled: true  },
    { id: "parking",  icon: "car",     enabled: true  },
    { id: "wifi",     icon: "wifi",    enabled: true  },
    { id: "kids",     icon: "kids",    enabled: true  },
    { id: "cards",    icon: "card",    enabled: true  }
  ],

  /* --- Отзывы -------------------------------------------------------------
     Реальные отзывы гостей. Формат: { author, rating, text, source }.
     author пока пустой — нужны имена авторов из Google, иначе карточка
     выглядит анонимной. Как пришлёшь имена, впиши их в author.
     Пустой массив полностью скрывает секцию отзывов. */
  reviews: [
    {
      author: "",
      rating: 5,
      source: "Google",
      text: "Incredible food, no words needed. Customer service and communication are top-notch. I'm a truck driver and ordered food in advance for 11 PM, even though they close at 10 PM — they still delivered it, and even threw in a free bonus. Thank you to everyone!"
    },
    {
      author: "",
      rating: 5,
      source: "Google",
      text: "Incredible tandoor samsa, just like in Uzbekistan! I've tried samsa in New York, Chicago, California, and many other places, and nothing compares to this. The plov and samsa are on another level — true tandoor style!"
    },
    {
      author: "",
      rating: 5,
      source: "Google",
      text: "The lamb shashlik was outstanding. The meat was tender and full of flavor, and the onions added a nice crunch. The honey cake for dessert was moist and the perfect way to end the meal."
    },
    {
      author: "",
      rating: 5,
      source: "Google",
      text: "The manti, samsa, and kebab were all so delicious. Amazing food, no complaints at all. The owners are incredibly hospitable people. We'll definitely come back."
    },
    {
      author: "",
      rating: 5,
      source: "Google",
      text: "Genuinely delicious! Portions are huge! The place is spotless! The staff, especially our waitress Alena, were amazing!!! I recommend it to everyone!"
    },
    {
      author: "",
      rating: 5,
      source: "Google",
      text: "I loved this place, prices included, and it was spotlessly clean inside. Great for anyone who drives trucks for a living, especially after a long haul. Great food and wonderful people."
    }
  ],

  /* --- Галерея (интерьер) -------------------------------------------------
     Заполнится, когда положишь фото зала в assets/img/interior/ */
  gallery: []
};
