/* ============================================================================
   SAMARKAND RESTAURANT — МЕНЮ
   ----------------------------------------------------------------------------
   ЧТОБЫ ПОМЕНЯТЬ ЦЕНУ — правь только число в поле price. Больше ничего.
   Вёрстка перестроится сама.

   ПОЛЯ БЛЮДА:
     id       — уникальный ключ (латиницей, без пробелов). Не менять.
     en       — название на английском
     ru       — название на русском
     desc     — описание (ТОЛЬКО на английском — требование ТЗ)
     price    — число в долларах. null = цена не подтверждена → на сайте
                вместо цены появится «Ask us / Уточняйте» вместо выдуманной суммы.
     unit     — необязательно: "pc" (за штуку), "cup", "pitcher", "sm", "lg"
     variants — необязательно: несколько размеров/цен одного позиции
     img      — имя файла в assets/img/dishes/. Если файла нет — покажется
                аккуратный орнаментальный плейсхолдер, вёрстка не поедет.
     tags     — "veg" (вегетарианское), "spicy" (острое), "signature" (хит)
     verify   — true: цена/описание требуют подтверждения у клиента

   ИСТОЧНИК ЦЕН: фотографии старого меню Registan Kebab House с Google Drive
   (Resgistan.1 / registan.3 / Entree.1 / Resgistan.4).
   ВНИМАНИЕ: страницы «salad», «Resgistan.2» и «*.Updated» прочитать не удалось —
   там цены на салаты, супы и, возможно, обновлённые цены на горячее и шашлык.
   ========================================================================== */

window.SAMARKAND_MENU = [

  /* ==========================================================  APPETIZERS  */
  {
    id: "appetizers",
    en: "Appetizers",
    ru: "Закуски",
    items: [
      {
        id: "uzbek-samsa",
        en: "Uzbek Samsa",
        ru: "Самса",
        desc: "Crispy pastry stuffed with lamb, beef, onions and spices. Served with a side of tomato sauce with garlic.",
        price: 4,
        unit: "pc",
        img: "uzbek-samsa.jpg",
        tags: ["signature"]
      },
      {
        id: "pickled-platter",
        en: "Pickled Platter",
        ru: "Соленья",
        desc: "House-pickled vegetables — a classic start to any Central Asian table.",
        price: null,
        img: "pickled-platter.jpg",
        tags: ["veg"],
        verify: true
      },
      {
        id: "cucumber-yogurt",
        en: "Cucumber Yogurt Salad",
        ru: "Огурцы с йогуртом",
        desc: "Fresh cucumbers in a cool yogurt dressing with herbs and garlic.",
        price: null,
        img: "cucumber-yogurt.jpg",
        tags: ["veg"],
        verify: true
      }
    ]
  },

  /* ==============================================================  SALADS  */
  {
    id: "salads",
    en: "Salads",
    ru: "Салаты",
    items: [
      {
        id: "achchik-chuchuk",
        en: "Achichuk (Achchik-Chuchuk)",
        ru: "Аччик-чучук",
        desc: "Thinly sliced tomatoes, onions and green chili — the traditional companion to plov.",
        price: null,
        img: "achchik-chuchuk.jpg",
        tags: ["veg", "spicy"],
        verify: true
      },
      {
        id: "garden-salad",
        en: "Garden Salad",
        ru: "Овощной салат",
        desc: "Fresh cucumbers, tomatoes, onions and herbs with a light dressing.",
        price: null,
        img: "garden-salad.jpg",
        tags: ["veg"],
        verify: true
      },
      {
        id: "greek-salad",
        en: "Greek Salad",
        ru: "Греческий салат",
        desc: "Cucumbers, tomatoes, bell pepper, olives and feta cheese.",
        price: null,
        img: "greek-salad.jpg",
        tags: ["veg"],
        verify: true
      },
      {
        id: "olivier-salad",
        en: "Olivier Salad",
        ru: "Оливье",
        desc: "The classic holiday salad — potatoes, carrots, eggs, peas and beef in a creamy dressing.",
        price: null,
        img: "olivier-salad.jpg",
        verify: true
      },
      {
        id: "carrot-salad",
        en: "Korean Carrot Salad",
        ru: "Морковча",
        desc: "Julienned carrots marinated with garlic, coriander and a gentle kick of heat.",
        price: null,
        img: "carrot-salad.jpg",
        tags: ["veg", "spicy"],
        verify: true
      }
    ]
  },

  /* ===============================================================  SOUPS  */
  {
    id: "soups",
    en: "Soups",
    ru: "Супы",
    items: [
      {
        id: "shurpa",
        en: "Shurpa",
        ru: "Шурпа",
        desc: "Rich lamb broth simmered with potatoes, carrots and herbs — the classic Uzbek soup.",
        price: null,
        img: "shurpa.jpg",
        tags: ["signature"],
        verify: true
      },
      {
        id: "mastava",
        en: "Mastava",
        ru: "Мастава",
        desc: "Hearty rice and vegetable soup with beef, finished with fresh herbs.",
        price: null,
        img: "mastava.jpg",
        verify: true
      },
      {
        id: "lagman",
        en: "Lagman",
        ru: "Лагман",
        desc: "Hand-pulled noodles in a savory broth with beef, bell peppers and vegetables.",
        price: null,
        img: "lagman.jpg",
        tags: ["signature"],
        verify: true
      },
      {
        id: "borsh",
        en: "Borsch",
        ru: "Борщ",
        desc: "Beet and cabbage soup with beef, served with sour cream.",
        price: null,
        img: "borsh.jpg",
        verify: true
      }
    ]
  },

  /* ========================================================  MAIN COURSES  */
  {
    id: "mains",
    en: "Main Courses",
    ru: "Горячее",
    items: [
      {
        id: "uzbek-plov",
        en: "Uzbek Plov",
        ru: "Плов",
        desc: "The most traditional Uzbek entree, made from special rice, beef, carrot and chickpeas.",
        price: 16,
        img: "uzbek-plov.jpg",
        tags: ["signature"]
      },
      {
        id: "toy-kabob",
        en: "To'y Kabob",
        ru: "Той-кабоб",
        desc: "Lamb stew with tomatoes.",
        price: 16,
        img: "toy-kabob.jpg"
      },
      {
        id: "manti",
        en: "Manti",
        ru: "Манты",
        desc: "Steamed Uzbek dumplings filled with beef, onions and spices. Served with yogurt (4 pcs).",
        price: 16,
        img: "manti.jpg",
        tags: ["signature"]
      },
      {
        id: "dolma",
        en: "Dolma",
        ru: "Долма",
        desc: "Grape leaves stuffed with beef, rice, onions and spices. Served with a side of sour cream (6–7 pcs).",
        price: 15,
        img: "dolma.jpg"
      },
      {
        id: "hanum",
        en: "Hanum",
        ru: "Ханум",
        desc: "Steamed fine rolled dough layered with diced potatoes, beef and onions. Served with tomato sauce.",
        price: 16,
        img: "hanum.jpg"
      },
      {
        id: "qurutob",
        en: "Qurutob",
        ru: "Курутоб",
        desc: "The national dish of Tajikistan — flaky flatbread soaked in qurut yogurt sauce, topped with onions, herbs and vegetables.",
        price: null,
        img: "qurutob.jpg",
        tags: ["signature"],
        verify: true
      },
      {
        id: "kazon-kabob",
        en: "Kazon Kabob",
        ru: "Казан-кабоб",
        desc: "Lamb and potatoes slow-cooked together in a cast-iron kazan until deeply tender.",
        price: null,
        img: "kazon-kabob.jpg",
        verify: true
      },
      {
        id: "roasted-cornish",
        en: "Roasted Cornish Hen & Fries",
        ru: "Цыплёнок с картофелем фри",
        desc: "Whole roasted Cornish hen served with a side of french fries.",
        price: null,
        img: "roasted-cornish.jpg",
        verify: true
      }
    ]
  },

  /* ================================================================  GRILL */
  {
    id: "grill",
    en: "Grill / Kebabs",
    ru: "Шашлык",
    items: [
      {
        id: "lyulya-kebab",
        en: "Lyulya Kebab",
        ru: "Люля-кебаб",
        desc: "A traditional premium juicy ground beef kebab.",
        price: 10,
        img: "lyulya-kebab.jpg",
        tags: ["signature"]
      },
      {
        id: "lamb-kebab",
        en: "Lamb Kebab",
        ru: "Шашлык из баранины",
        desc: "Marinated tender lamb, very soft and juicy.",
        price: 12,
        img: "lamb-kebab.jpg",
        tags: ["signature"]
      },
      {
        id: "beef-kebab",
        en: "Beef Kebab",
        ru: "Шашлык из говядины",
        desc: "Marinated tender beef, very soft and juicy.",
        price: 12,
        img: "beef-kebab.jpg"
      },
      {
        id: "chicken-kebab",
        en: "Chicken Kebab",
        ru: "Шашлык из курицы",
        desc: "Seasoned boneless chicken thighs.",
        price: 10,
        img: "chicken-kebab.jpg"
      },
      {
        id: "salmon-kebab",
        en: "Salmon Kebab",
        ru: "Шашлык из лосося",
        desc: "Cubed and marinated salmon, grilled over open coals.",
        price: 12,
        img: "salmon-kebab.jpg"
      },
      {
        id: "lamb-chops",
        en: "Lamb Chops",
        ru: "Бараньи рёбрышки",
        desc: "Marinated tender lamb chops, very soft and juicy.",
        price: 20,
        img: "lamb-chops.jpg"
      },
      {
        id: "kebab-meal",
        en: "Kebab Meal",
        ru: "Кебаб-сет",
        desc: "Beef and chicken kebab with rice on the side.",
        price: 23,
        img: "kebab-meal.jpg"
      },
      {
        id: "combo-mix-kebab",
        en: "Combo Mix Kebab",
        ru: "Ассорти шашлыков",
        desc: "4 skewers of shish kebab — lamb, beef, chicken and lyulya — served with a side of potatoes, tomatoes and onions.",
        price: 49,
        img: "combo-mix-kebab.jpg",
        tags: ["signature"]
      }
    ]
  },

  /* ======================================================  BREAD & SIDES  */
  {
    id: "sides",
    en: "Bread & Sides",
    ru: "Хлеб и гарниры",
    items: [
      {
        id: "non",
        en: "Non (Lepeshka)",
        ru: "Нон (лепёшка)",
        desc: "A flavorful Uzbek bread, baked fresh in the tandoor.",
        price: 5,
        unit: "pc",
        img: "non.jpg",
        tags: ["veg", "signature"]
      },
      {
        id: "rice",
        en: "Rice",
        ru: "Рис",
        desc: "A side of steamed rice.",
        price: 5,
        img: "rice.jpg",
        tags: ["veg"]
      },
      {
        id: "fried-potatoes",
        en: "Fried Potatoes",
        ru: "Жареный картофель",
        desc: "Home-style fried potatoes.",
        price: 8,
        img: "fried-potatoes.jpg",
        tags: ["veg"]
      },
      {
        id: "french-fries",
        en: "French Fries",
        ru: "Картофель фри",
        desc: "A side of crispy french fries.",
        price: 5,
        img: "french-fries.jpg",
        tags: ["veg"],
        verify: true
      }
    ]
  },

  /* ============================================================  DESSERTS  */
  {
    id: "desserts",
    en: "Desserts",
    ru: "Десерты",
    items: [
      {
        id: "paklava",
        en: "Baklava",
        ru: "Пахлава",
        desc: "Middle Eastern pastry, baked with walnuts and raisins. Contains nuts.",
        price: 5,
        unit: "pc",
        img: "paklava.jpg",
        tags: ["veg"]
      },
      {
        id: "medovik",
        en: "Medovik",
        ru: "Медовик",
        desc: "A rich cake with several layers of honey, cream and caramel.",
        price: 6,
        unit: "pc",
        img: "medovik.jpg",
        tags: ["veg"]
      }
    ]
  },

  /* ==============================================================  DRINKS  */
  {
    id: "drinks",
    en: "Drinks",
    ru: "Напитки",
    items: [
      {
        id: "compot",
        en: "Compot",
        ru: "Компот",
        desc: "Homemade punch made with seasonal fresh fruits.",
        price: 4,
        variants: [
          { en: "Cup",     ru: "Стакан", price: 4 },
          { en: "Pitcher", ru: "Кувшин", price: 10 }
        ],
        img: "compot.jpg",
        tags: ["veg", "signature"]
      },
      {
        id: "sweet-tea",
        en: "Sweet Tea with Lemon",
        ru: "Чай с лимоном",
        desc: "Brewed sweet tea served with fresh lemon.",
        price: 6,
        variants: [
          { en: "Small", ru: "Маленький", price: 6 },
          { en: "Large", ru: "Большой",   price: 8 }
        ],
        img: "sweet-tea.jpg",
        tags: ["veg"]
      },
      {
        id: "ayran",
        en: "Ayran",
        ru: "Айран",
        desc: "Chilled salted yogurt drink. Contains dairy.",
        price: 3,
        img: "ayran.jpg",
        tags: ["veg"]
      },
      {
        id: "kefir",
        en: "Kefir",
        ru: "Кефир",
        desc: "Cultured yogurt drink. Contains dairy.",
        price: 2,
        img: "kefir.jpg",
        tags: ["veg"]
      },
      {
        id: "coffee",
        en: "Coffee",
        ru: "Кофе",
        desc: "Freshly brewed coffee.",
        price: 4,
        img: "coffee.jpg",
        tags: ["veg"]
      },
      {
        id: "soda",
        en: "Soda",
        ru: "Газировка",
        desc: "Sprite or Coca-Cola.",
        price: 3,
        img: "soda.jpg",
        tags: ["veg"]
      },
      {
        id: "bottled-soda",
        en: "Bottled Soda",
        ru: "Газировка в бутылке",
        desc: "Bottled soft drink.",
        price: 5,
        img: "bottled-soda.jpg",
        tags: ["veg"]
      },
      {
        id: "sparkling-water",
        en: "Sparkling Water",
        ru: "Газированная вода",
        desc: "Chilled sparkling mineral water.",
        price: 3,
        img: "sparkling-water.jpg",
        tags: ["veg"]
      }
    ]
  }
];
